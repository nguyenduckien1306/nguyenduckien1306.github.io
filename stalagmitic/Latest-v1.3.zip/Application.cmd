start cli.exe pkey.txt
